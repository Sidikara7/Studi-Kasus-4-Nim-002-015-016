#include <iostream>
#include <fstream>
using namespace std;
#include "../library/output.h"

int main() {

  outPut keluar;
  keluar.getData();
  keluar.dataOut();
  
  return 0;
}