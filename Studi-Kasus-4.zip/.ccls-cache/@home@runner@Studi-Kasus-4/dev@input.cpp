#include <iostream>
#include <fstream>
using namespace std;
#include "../library/input.h"

int main() {
  Input input;
  input.cetak();
  input.toFile();
  return 0;
}